package com.vibemusic.app.data

import com.vibemusic.app.BuildConfig
import com.vibemusic.app.model.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

class JamendoRepository {
    suspend fun searchTracks(query: String = ""): List<Track> = withContext(Dispatchers.IO) {
        val clientId = BuildConfig.JAMENDO_CLIENT_ID
        require(clientId.isNotBlank()) {
            "Jamendo Client ID belum diatur. Tambahkan JAMENDO_CLIENT_ID di local.properties."
        }

        val encodedQuery = URLEncoder.encode(query.trim(), "UTF-8")
        val queryPart = if (encodedQuery.isBlank()) "" else "&search=$encodedQuery"
        val endpoint =
            "https://api.jamendo.com/v3.0/tracks/?client_id=$clientId" +
            "&format=json&limit=30&audioformat=mp32&imagesize=300" +
            "&order=popularity_total&include=licenses$queryPart"

        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Accept", "application/json")
        }

        try {
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (status !in 200..299) {
                throw IllegalStateException("Jamendo API mengembalikan HTTP $status")
            }

            val json = JSONObject(body)
            val headers = json.optJSONObject("headers")
            if (headers != null && headers.optString("status") == "failed") {
                throw IllegalStateException(headers.optString("error_message", "Permintaan API gagal"))
            }

            val results = json.optJSONArray("results") ?: return@withContext emptyList()
            buildList {
                for (index in 0 until results.length()) {
                    val item = results.optJSONObject(index) ?: continue
                    val audio = item.optString("audio")
                    if (audio.isBlank() || audio == "null") continue
                    add(
                        Track(
                            id = item.optString("id"),
                            title = item.optString("name", "Unknown track"),
                            artist = item.optString("artist_name", "Unknown artist"),
                            album = item.optString("album_name", ""),
                            audioUrl = audio,
                            imageUrl = item.optString("image"),
                            licenseUrl = item.optString("license_ccurl"),
                            shareUrl = item.optString("shareurl")
                        )
                    )
                }
            }
        } finally {
            connection.disconnect()
        }
    }
}
