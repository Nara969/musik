package com.vibemusic.app

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import org.json.JSONArray
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.ListenableFuture
import com.vibemusic.app.data.JamendoRepository
import com.vibemusic.app.model.Track
import com.vibemusic.app.player.PlaybackService
import kotlinx.coroutines.launch

private val Night = Color(0xFF090D0B)
private val Panel = Color(0xFF151C18)
private val Green = Color(0xFF35D07F)
private val Muted = Color(0xFFA5B2AA)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener(
            { runCatching { controller = controllerFuture?.get() } },
            ContextCompat.getMainExecutor(this)
        )

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Night,
                    surface = Panel,
                    primary = Green,
                    onPrimary = Night,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                VibeMusicApp(controller)
            }
        }
    }

    override fun onDestroy() {
        controllerFuture?.let(MediaController::releaseFuture)
        controller = null
        super.onDestroy()
    }
}

@Composable
private fun VibeMusicApp(controller: MediaController?) {
    val repository = remember { JamendoRepository() }
    val scope = rememberCoroutineScope()
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    val appContext = LocalContext.current
    val prefs = remember { appContext.getSharedPreferences("vibemusic", android.content.Context.MODE_PRIVATE) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var history by remember { mutableStateOf(prefs.getStringSet("history", emptySet())?.toList() ?: emptyList()) }
    var shuffle by remember { mutableStateOf(false) }
    var repeatOne by remember { mutableStateOf(false) }
    var queue by remember { mutableStateOf<List<Track>>(emptyList()) }
    var selected by remember { mutableStateOf<Track?>(null) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }

    fun load(search: String) {
        scope.launch {
            loading = true
            error = null
            try {
                tracks = repository.searchTracks(search)
            } catch (e: Exception) {
                error = e.message ?: "Tidak dapat memuat katalog musik."
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { load("") }

    DisposableEffect(controller) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }
        }
        controller?.addListener(listener)
        onDispose { controller?.removeListener(listener) }
    }

    fun toggleFavorite(track: Track) {
        favorites = if (track.id in favorites) favorites - track.id else favorites + track.id
        prefs.edit().putStringSet("favorites", favorites).apply()
    }

    fun play(track: Track) {
        selected = track
        history = (listOf(track.id) + history.filterNot { it == track.id }).take(100)
        prefs.edit().putStringSet("history", history.toSet()).apply()
        val sourceQueue = (listOf(track) + tracks.filterNot { it.id == track.id }).distinctBy { it.id }
        queue = sourceQueue
        val metadata = MediaMetadata.Builder()
            .setTitle(track.title)
            .setArtist(track.artist)
            .setArtworkUri(track.imageUrl.takeIf { it.startsWith("http") }?.let(Uri::parse))
            .build()
        val item = MediaItem.Builder()
            .setUri(track.audioUrl)
            .setMediaMetadata(metadata)
            .build()
        controller?.apply {
            val items = sourceQueue.map { t ->
                MediaItem.Builder().setUri(t.audioUrl).setMediaMetadata(
                    MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist)
                        .setArtworkUri(t.imageUrl.takeIf { it.startsWith("http") }?.let(Uri::parse)).build()
                ).build()
            }
            setMediaItems(items, 0, 0L)
            shuffleModeEnabled = shuffle
            repeatMode = if (repeatOne) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
            prepare()
            play()
        }
    }

    Scaffold(
        containerColor = Night,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Color.White) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.Search, null) },
                    label = { Text("Search") }
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.LibraryMusic, null) },
                    label = { Text("Library") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding)
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(38.dp).clip(CircleShape).background(Green),
                    contentAlignment = Alignment.Center
                ) { Text("V", color = Night, fontWeight = FontWeight.Black, fontSize = 22.sp) }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("VibeMusic", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Your sound. Your space.", color = Muted, fontSize = 11.sp)
                }
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.Favorite, null, tint = Green)
            }

            Spacer(Modifier.height(20.dp))

            when (tab) {
                0 -> {
                    Text("Good music, good mood.", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Discover independent music", color = Muted)
                    Spacer(Modifier.height(16.dp))
                    SectionTitle("Popular right now")
                    TrackContent(tracks, loading, error, favorites, onPlay = ::play, onFavorite = ::toggleFavorite)
                }
                1 -> {
                    Text("Find your vibe", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        placeholder = { Text("Search tracks, artists, albums…") },
                        trailingIcon = {
                            IconButton(onClick = { load(query) }) {
                                Icon(Icons.Default.Search, null, tint = Green)
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Green,
                            unfocusedBorderColor = Muted,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Spacer(Modifier.height(12.dp))
                    TrackContent(tracks, loading, error, favorites, onPlay = ::play, onFavorite = ::toggleFavorite)
                }
                2 -> {
                    Text("Your library", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("${favorites.size} saved tracks • ${history.size} recently played", color = Muted)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = false, onClick = { tab = 3 }, label = { Text("Favorites") })
                        FilterChip(selected = false, onClick = { tab = 4 }, label = { Text("History") })
                    }
                    Spacer(Modifier.height(12.dp))
                    TrackContent(
                        tracks.filter { it.id in favorites },
                        loading = false,
                        error = null,
                        favorites = favorites,
                        onPlay = ::play,
                        onFavorite = ::toggleFavorite
                    )
                }
                3 -> {
                    Text("Favorites", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    TrackContent(tracks.filter { it.id in favorites }, false, null, favorites, ::play, ::toggleFavorite)
                }
                4 -> {
                    Text("Recently played", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    TrackContent(history.mapNotNull { id -> tracks.find { it.id == id } }, false, null, favorites, ::play, ::toggleFavorite)
                }
            }

            selected?.let { track ->
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .background(Panel).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = track.imageUrl,
                        contentDescription = "Cover ${track.title}",
                        modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
                        Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1)
                    }
                    IconButton(onClick = { shuffle = !shuffle; controller?.shuffleModeEnabled = shuffle }) {
                        Text("🔀", color = if (shuffle) Green else Muted)
                    }
                    IconButton(onClick = { controller?.seekToPreviousMediaItem() }) {
                        Text("|◀", color = Color.White)
                    }
                    IconButton(onClick = {
                        if (controller?.isPlaying == true) controller?.pause() else controller?.play()
                    }) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Green
                        )
                    }
                    IconButton(onClick = { controller?.seekToNextMediaItem() }) {
                        Text("▶|", color = Color.White)
                    }
                    IconButton(onClick = {
                        repeatOne = !repeatOne
                        controller?.repeatMode = if (repeatOne) Player.REPEAT_MODE_ONE else Player.REPEAT_MODE_OFF
                    }) { Text("🔁", color = if (repeatOne) Green else Muted) }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun TrackContent(
    tracks: List<Track>,
    loading: Boolean,
    error: String?,
    favorites: Set<String>,
    onPlay: (Track) -> Unit,
    onFavorite: (Track) -> Unit
) {
    when {
        loading -> Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Green)
        }
        error != null -> Text(error, color = Color(0xFFFF8A80), modifier = Modifier.padding(12.dp))
        tracks.isEmpty() -> Text("No tracks found. Check your API setup or try another search.", color = Muted)
        else -> LazyColumn(
            modifier = Modifier.fillMaxWidth().weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tracks, key = { it.id }) { track ->
                Row(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(Panel).clickable { onPlay(track) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = track.imageUrl,
                        contentDescription = "Album cover",
                        modifier = Modifier.size(54.dp).clip(RoundedCornerShape(9.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, maxLines = 1, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (track.album.isBlank()) track.artist else "${track.artist} • ${track.album}",
                            maxLines = 1,
                            color = Muted,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = { onFavorite(track) }) {
                        Icon(
                            Icons.Default.Favorite,
                            contentDescription = "Favorite",
                            tint = if (track.id in favorites) Green else Muted
                        )
                    }
                    IconButton(onClick = { onPlay(track) }) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Green)
                    }
                }
            }
        }
    }
}
