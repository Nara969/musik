package com.vibemusic.app.model

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val audioUrl: String,
    val imageUrl: String,
    val licenseUrl: String,
    val shareUrl: String
)
