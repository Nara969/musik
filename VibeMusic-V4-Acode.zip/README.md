# VibeMusic V4

An original, ad-free Android music player starter built with Kotlin, Jetpack Compose and AndroidX Media3. The first catalog provider is Jamendo's public read API.

## Included in this starter

- Dark interface with original green visual identity
- Home catalogue and track search
- Track artwork, title, artist and album
- Playback through AndroidX Media3 / ExoPlayer
- MediaSessionService for background playback and system media controls
- Local favorites for the current app session
- No advertising SDK or ad placements

## Requirements

- Android Studio with Android SDK 36
- JDK 17
- Gradle 8.13-compatible Android Gradle Plugin
- A Jamendo developer Client ID

## Configure the music API

1. Register an application in the Jamendo developer portal:
   https://devportal.jamendo.com/
2. Create `local.properties` in the project root (next to `settings.gradle.kts`).
3. Add this line:

   `JAMENDO_CLIENT_ID=YOUR_CLIENT_ID`

4. Sync Gradle and run the `app` configuration.

The Client ID is an application identifier, not a client secret. Do not put any client secret in the Android app. The API currently documents a test-only ID for read API experiments; register your own ID for normal development.

## Build

Open this folder in Android Studio, allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important catalog and licensing notes

Jamendo's API terms state that its content is published under Creative Commons licenses, and each track's license must be respected. The terms currently distinguish non-commercial use from commercial use; commercial use requires contacting Jamendo for licensing. The terms also prohibit building an app that copies Jamendo's overall experience or confusingly similar look and feel. VibeMusic therefore uses its own name, colors, layout and interaction design.

This starter does not contain Spotify's catalogue, Spotify credentials, or copyrighted Spotify assets. "Ad-free" means this app contains no advertising placements or advertising SDK; it does not remove ads from third-party services or change a provider's own terms.

## Current implementation status

This is a source-project starter, not a signed APK. It has not been compiled in this environment because an Android SDK/Gradle build environment is not available here. Build it in Android Studio after adding your own Jamendo Client ID.

Favorites currently remain in memory and reset when the app process is recreated. Persistent playlists, account sync, downloads/offline mode, recommendations, lyrics, equalizer and release signing are not included in this first build.

## Core playback improvements

This source revision adds locally persisted favorite IDs and recently played IDs using Android SharedPreferences, builds a playable Media3 queue from the currently loaded catalog, and exposes previous/next, shuffle, and repeat-one controls in the mini player. Favorites and history are device-local and are not synced between devices. History can only display tracks present in the currently loaded catalog.

## Important limitations

This is not a Spotify-equivalent catalog or service. Jamendo provides independent/Creative Commons music; availability, attribution, and permitted use depend on each track's license. This revision does not implement user accounts/cloud sync, persistent named playlists, synchronized lyrics, guaranteed offline downloads, personalized recommendation models, or a full equalizer UI. No advertising SDK is included. Build and device testing are still required before release.
